import random
import json
import os

from pico2d import *

import game_framework
import title_state

name = "MainState"

class BG:
    def __init__(self):
        self.image = load_image('BG.png')

    def draw(self):
        self.image.draw(400, 350)



class FireBall1:
    global Fbinput
    image = None

    def __init__(self):
        self.x, self.y = 30, random.randint(0, 800)
        self.k = random.randint(1,6)
        self.image = load_image('FB.png')
        self.Fbinput = False
    def draw(self):
        self.image.clip_draw(0, 0, 30, 27, self.x, self.y)

    def updata(self):
        if self.k == 1:
            self.x += 20
            if self.x > 800:
                self.x = 0
                self.y += 10
        elif self.k == 2:
            self.x += 8
            self.y += 1
            if self.x > 800:
                self.x = 0
                self.y += 10
        elif self.k == 3:
            self.x += 16
            self.y += 2
            if self.x > 800:
                self.x = 0
                self.y += 10
        elif self.k == 4:
            self.x += 14
            self.y += 2
            if self.x > 800:
                self.x = 0
                self.y += 10
        elif self.k == 5:
            self.x += 18
            self.y -= 1
            if self.x > 800:
                self.x = 0
                self.y += 10
        elif self.k == 6:
            self.x += 10
            self.y -= 2
            if self.x > 800:
                self.x = 0
                self.y += 10

class FireBall2:
    global Fbinput
    image = None

    def __init__(self):
        self.x, self.y = random.randint(0, 800) , 10
        self.k = random.randint(1,6)
        self.image = load_image('FB.png')
        self.Fbinput = False
    def draw(self):
        self.image.clip_draw(0, 0, 30, 27, self.x, self.y)

    def updata(self):
        if self.k == 1:
            self.y += 20
            if self.y > 700:
                self.y = 0
                self.x += 10

        elif self.k == 2:
            self.y += 8
            self.x += 1
            if self.y > 700:
                self.y = 0
                self.x += 10
        elif self.k == 3:
            self.y += 16
            self.x += 2
            if self.y > 700:
                self.y = 0
                self.x += 10
        elif self.k == 4:
            self.y += 14
            self.x += 2
            if self.y > 700:
                self.y = 0
                self.x += 10
        elif self.k == 5:
            self.y += 18
            self.x -= 1
            if self.y > 700:
                self.y = 0
                self.x += 10
        elif self.k == 6:
            self.y += 10
            self.x -= 2
            if self.y > 700:
                self.y = 0
                self.x += 10

class Witch:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10 pixel 30 cm
    RUN_SPEED_KMPH = 20.0  # Km / Hour
    RUN_SPEED_MPM = (RUN_SPEED_KMPH * 1000.0 / 60.0)
    RUN_SPEED_MPS = (RUN_SPEED_MPM / 60.0)
    RUN_SPEED_PPS = (RUN_SPEED_MPS * PIXEL_PER_METER)

    TIME_PER_ACTION = 0.5
    ACTION_PER_TIME = 1.0 / TIME_PER_ACTION
    FRAMES_PER_ACTION = 8

    image = None
    UP_RUN, RIGHT_RUN, LEFT_RUN,  DOWN_RUN, STAY = 0,1,2,3, 4

    def __init__(self):
        self.x, self.y = 400, 90
        self.frame = 1
        self.life_time = 0.0
        self.total_frames = 0.0
        self.state = self.STAY
        if Witch.image == None:
            Witch.image = load_image('FL_ANIME.png')

    def update(self, frame_time):
        self.life_time += frame_time
        self.total_frames += Witch.FRAMES_PER_ACTION * Witch.ACTION_PER_TIME * frame_time
        distance = Witch.RUN_SPEED_PPS * frame_time
        self.frame = (self.frame+1) %3
        self.handle_state[self.state](self)

    def handle_stay(self):
        global Uinput
        global Dinput
        global Rinput
        global Linput
        global Sinput

        self.x = self.x
        self.y = self.y
        if Uinput == True :
            self.state = self.UP_RUN
            Uinput = False
        elif Dinput == True :
            self.state = self.DOWN_RUN
            Dinput = False
        elif Rinput == True :
            self.state = self.RIGHT_RUN
            Rinput = False
        elif Linput == True :
            self.state = self.LEFT_RUN
            Linput = False

    def handle_down_run(self,frame_time):
        global Uinput
        global Dinput
        global Rinput
        global Linput
        global Sinput
        distance = Witch.RUN_SPEED_PPS * frame_time
        self.y -= distance
        if self.y <0 :
            self.y = 0
        if Uinput == True :
            self.state = self.UP_RUN
            Uinput = False
        elif Rinput == True :
            self.state = self.RIGHT_RUN
            Rinput = False
        elif Linput == True :
            self.state = self.LEFT_RUN
            Linput = False

    def handle_left_run(self,frame_time):
        global Uinput
        global Dinput
        global Rinput
        global Linput
        global Sinput
        distance = Witch.RUN_SPEED_PPS * frame_time
        self.x -= distance
        if self.x < 0 :
            self.x =0

        if Uinput == True :
            self.state = self.UP_RUN
            Uinput = False
        elif Dinput == True :
            self.state = self.DOWN_RUN
            Dinput = False
        elif Rinput == True :
            self.state = self.RIGHT_RUN
            Rinput = False

    def handle_right_run(self,frame_time):
        global Uinput
        global Dinput
        global Rinput
        global Linput
        global Sinput
        distance = Witch.RUN_SPEED_PPS * frame_time
        self.x += distance
        if self.x > 800:
            self.x = 800
        if Uinput == True :
            self.state = self.UP_RUN
            Uinput = False
        elif Dinput == True :
            self.state = self.DOWN_RUN
            Dinput = False
        elif Linput == True :
            self.state = self.LEFT_RUN
            Linput = False

    def handle_up_run(self,frame_time):
        distance = Witch.RUN_SPEED_PPS * frame_time
        global Uinput
        global Dinput
        global Rinput
        global Linput
        global Sinput

        self.y += distance
        if self.y > 800:
            self.y= 800
        if Dinput == True:
            self.state = self.DOWN_RUN
            Dinput = False
        elif Linput == True:
            self.state = self.LEFT_RUN
            Linput = False
        elif Rinput == True :
            self.state = self.RIGHT_RUN
            Rinput = False

    def handle_events(self, event):
        global running
        global Uinput
        global Dinput
        global Rinput
        global Linput
        global Sinput

        events = get_events()
        for event in events:
            if event.type == SDL_QUIT:
                running = False
            elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
                running = False
            elif event.type == SDL_KEYDOWN and event.key == SDLK_DOWN:
                Dinput = True
            elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:
                Uinput = True
            elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
                Linput = True
            elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
                Rinput = True
            elif event.type == SDL_KEYDOWN and event.key == SDLK_SPACE:
                Sinput = True

    handle_state = {
        DOWN_RUN : handle_down_run,
        LEFT_RUN : handle_left_run,
        RIGHT_RUN : handle_right_run,
        UP_RUN : handle_up_run,
        STAY : handle_stay
    }



    def draw(self):
        self.image.clip_draw(self.frame * 30, self.state * 32, 30, 32, self.x, self.y)

def enter():
    global witch, FB1, FB2, grass
    witch = Witch()
    FB1 = FireBall1()
    FB2 = FireBall2()
    grass = BG
    game_framework.reset_time()

def exit():
    global witch, FB1, FB2 , grass
    del(witch)
    del(FB1)
    del(FB2)
    del(grass)

def pause():
    pass


def resume():
    pass

def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and event.key == SDLK_ESCAPE:
            running = False
        elif event.type == SDL_KEYDOWN and event.key == SDLK_DOWN:
            Dinput = True
        elif event.type == SDL_KEYDOWN and event.key == SDLK_UP:
            Uinput = True
        elif event.type == SDL_KEYDOWN and event.key == SDLK_LEFT:
            Linput = True
        elif event.type == SDL_KEYDOWN and event.key == SDLK_RIGHT:
            Rinput = True
        elif event.type == SDL_KEYDOWN and event.key == SDLK_SPACE:
            Sinput = True

